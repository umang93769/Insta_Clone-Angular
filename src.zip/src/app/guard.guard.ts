import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
 
export interface CanComponentDeactivate {
  canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}

@Injectable({
  providedIn: 'root'
})
@Injectable({
  providedIn: 'root'
})
export class GuardGuard implements CanDeactivate<CanComponentDeactivate> {
  canDeactivate(component:CanComponentDeactivate):any{
    console.log("can deactivate check");
        return component && component.canDeactivate
          ? component.canDeactivate()
          :true;
  }
}

