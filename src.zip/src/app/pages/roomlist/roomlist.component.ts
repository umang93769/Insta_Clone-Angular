import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FirebaseTSFirestore, Limit, OrderBy } from 'firebasets/firebasetsFirestore/firebaseTSFirestore';
import { CreateRoomComponent } from 'src/app/tools/create-room/create-room.component';
@Component({
  selector: 'app-roomlist',
  templateUrl: './roomlist.component.html',
  styleUrls: ['./roomlist.component.css']
})
export class RoomlistComponent implements OnInit {
  rooms:RoomData[]=[];
  constructor(private dialog:MatDialog) { }
  firestore=new FirebaseTSFirestore();
  ngOnInit(): void {
    this.getRooms();
  }
  onCreateRoomClick(){
    this.dialog.open(CreateRoomComponent);
  }
  getRooms(){
    this.firestore.getCollection(
      {
        path:["Rooms"],
        where:[
          //new Where("creatorId","==","F2okg35GJ4eo8kASrmmRHAzCfG82"),
          new OrderBy("timestamp","desc"),
          new Limit(10),
        ],
        onComplete:(result)=>{
          result.docs.forEach(
            doc=>{
              let room= <RoomData>doc.data();
              room.roomId=doc.id;
              this.rooms.push(room);
            }
          )
        },
        onFail:err=>{

        }
      }
    )
  }
}
export interface RoomData{
  comment:string;
  creatorId:string;
  roomId:string;
}