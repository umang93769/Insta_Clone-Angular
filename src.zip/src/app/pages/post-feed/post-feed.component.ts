import { Component, NgModule, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CreatePostComponent } from 'src/app/tools/create-post/create-post.component';
import { FirebaseTSFirestore, Limit, OrderBy, Where } from 'firebasets/firebasetsFirestore/firebaseTSFirestore';
import { Router } from '@angular/router';
@Component({
  selector: 'app-post-feed',
  templateUrl: './post-feed.component.html',
  styleUrls: ['./post-feed.component.css']
})
export class PostFeedComponent implements OnInit {
  insta_add: string="/assets/add.svg";
  insta_msg: string="/assets/msg.svg";
  constructor(private dialog:MatDialog,private router:Router) { }
  firestore=new FirebaseTSFirestore();
  posts:PostData[]=[];
  ngOnInit(): void {
    this.getPosts();
  }
  onCreatePostClick()
  {
    this.dialog.open(CreatePostComponent);
  }
  onRoom(){
    this.router.navigate(["room"]);
  }
  onAccount(){
    this.router.navigate(["account"]);
  }
  getPosts()
  {
    this.firestore.getCollection(
      {
        path:["Posts"],
        where:[
          //new Where("creatorId","==","F2okg35GJ4eo8kASrmmRHAzCfG82"),
          new OrderBy("timestamp","desc"),
          new Limit(10),
        ],
        onComplete:(result)=>{
          result.docs.forEach(
            doc=>{
              let post= <PostData>doc.data();
              post.postId=doc.id;
              this.posts.push(post);
            }
          )
        },
        onFail:err=>{

        }
      }
    )
  }
  canDeactivate(){
    return new Promise((resolve, reject) => {
      resolve(confirm("do you want to logout?"))  
    })
   }
}

export interface PostData{
  comment:string;
  creatorId:string;
  imageUrl?:string;
  postId:string;
}