import { Component, OnInit } from '@angular/core';
import { FirebaseTSAuth } from 'firebasets/firebasetsAuth/firebaseTSAuth';
import { FirebaseTSFirestore, Limit, OrderBy, Where } from 'firebasets/firebasetsFirestore/firebaseTSFirestore';

@Component({
  selector: 'app-profilefeed',
  templateUrl: './profilefeed.component.html',
  styleUrls: ['./profilefeed.component.css']
})
export class ProfilefeedComponent implements OnInit {
  firestore=new FirebaseTSFirestore();
  posts:PostData[]=[];
  rooms:RoomData[]=[];
  auth =new FirebaseTSAuth();
  constructor() { 
  }

  ngOnInit(): void {
     this.getPosts();
     this.getRooms();
  }
  getPosts()
  { 
    this.firestore.getCollection(
      {
        path:["Posts"],
        where:[
         // new Where("creatorId","==",this.auth.getAuth().currentUser.uid),
          new OrderBy("timestamp","desc"),
          new Limit(10),
        ],
        onComplete:(result)=>{
          result.docs.forEach(
            doc=>{
              let post= <PostData>doc.data();
              post.postId=doc.id;
              post.creatorId=this.auth.getAuth().currentUser.uid;
              this.posts.push(post);
            }
          )
        },
        onFail:err=>{

        }
      }
    )
  }
  getRooms()
  {
    this.firestore.getCollection(
      {
        path:["Rooms"],
        where:[
         // new Where("creatorId","==",this.auth.getAuth().currentUser.uid),
          new OrderBy("timestamp","desc"),
          new Limit(10),
        ],
        onComplete:(result)=>{
          result.docs.forEach(
            doc=>{
              let room= <RoomData>doc.data();
              room.roomId=doc.id;
              room.creatorId=this.auth.getAuth().currentUser.uid;
              this.rooms.push(room);
            }
          )
        },
        onFail:err=>{

        }
      }
    )
  }
}
export interface PostData{
  comment:string;
  creatorId:string;
  imageUrl?:string;
  postId:string;
}
export interface RoomData{
  comment:string;
  creatorId:string;
  roomId:string;
}