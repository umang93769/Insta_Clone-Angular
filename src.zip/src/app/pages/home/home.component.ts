import { Component, OnInit } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { AuthenticatorComponent } from 'src/app/tools/authenticator/authenticator.component';
import { FirebaseTSAuth } from 'firebasets/firebasetsAuth/firebaseTSAuth';

import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  username:string="";
  password:string="";

  firebasetsAuth:FirebaseTSAuth;
  constructor(private loginSheet:MatBottomSheet,private router:Router) {
    this.firebasetsAuth=new FirebaseTSAuth();
   }
  
  ngOnInit(): void {
  }
  OnGetStartedClick(){
    this.loginSheet.open(AuthenticatorComponent)
  }
  Submit(){
    console.log("hi");
    let email=this.username;
    let password=this.password;
    this.firebasetsAuth.signInWith(
      {
        email:email,
        password:password,
        onComplete:(uc)=>{
          this.router.navigateByUrl("postfeed");
        },
        onFail:(err)=>{
          alert(err);
        }
      }
    )
  }
}

