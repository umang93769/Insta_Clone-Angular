import { Component, Inject, OnInit } from '@angular/core';
import { FirebaseTSApp } from 'firebasets/firebasetsApp/firebaseTSApp';
import { FirebaseTSFirestore, OrderBy } from 'firebasets/firebasetsFirestore/firebaseTSFirestore';
import { AppComponent } from 'src/app/app.component';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) private roomId: string ) { }
  firestore=new FirebaseTSFirestore();
  comments:Comment [] = [];
  ngOnInit(): void {
    this.getComments();
  }
  isCommentCreator(comment:Comment)
  {
    try{
      return comment.creatorId == AppComponent.getUserDocument().userId;
    }
    catch(err){
      
    }
  }
  getComments(){
    this.firestore.listenToCollection(
      {
        name:"Room Comments",
        path:["Rooms",this.roomId,"RoomComments"],
        where:[new OrderBy("timestamp","asc")],
        onUpdate:(result)=>{
          result.docChanges().forEach(
            postCommentDoc => {
              if(postCommentDoc.type == "added")
              {
                this.comments.unshift (<Comment>postCommentDoc.doc.data())
              }
            }
          );
        }
      }
    );
  }
  onSendClick(commentInput:HTMLInputElement){
    if(!(commentInput.value.length>0)) return;
    this.firestore.create(
      {
        path:["Rooms",this.roomId,"RoomComments"],
        data:{
          comment:commentInput.value,
          creatorId:AppComponent.getUserDocument().userId,
          creatorName:AppComponent.getUserDocument().publicName,
          timestamp:FirebaseTSApp.getFirestoreTimestamp()
        },
        onComplete:(docId)=>{
          commentInput.value="";
        }
      }
    )
   }
}
export interface Comment {
  creatorId:string;
  creatorName:string;
  comment:string;
  timestamp:firebase.default.firestore.Timestamp
}