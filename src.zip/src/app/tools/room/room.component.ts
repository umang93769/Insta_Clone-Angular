import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FirebaseTSFirestore } from 'firebasets/firebasetsFirestore/firebaseTSFirestore';
import { RoomData } from 'src/app/pages/roomlist/roomlist.component';
import { ChatComponent } from '../chat/chat.component';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {
  @Input() roomData:RoomData;
  creatorName:string | undefined;
  creatorDescription:string | undefined;
  constructor(private dialog:MatDialog) { }
  firestore= new FirebaseTSFirestore();
  ngOnInit(): void {
    this.getCreatorInfo();
  }
  onChatClick()
  {
    this.dialog.open(ChatComponent,{data:this.roomData.roomId});
  }
  getCreatorInfo(){
    this.firestore.getDocument(
      {
         path:["Users",this.roomData?.creatorId||''],
         onComplete : result =>{
          let userDocument=result.data();
          this.creatorName=userDocument?.['publicName'];
          this.creatorDescription=userDocument?.['description'];
         }

      }
    );
  }
}
