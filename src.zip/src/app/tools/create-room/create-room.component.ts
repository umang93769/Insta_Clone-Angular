import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FirebaseTSApp } from 'firebasets/firebasetsApp/firebaseTSApp';
import { FirebaseTSAuth } from 'firebasets/firebasetsAuth/firebaseTSAuth';
import { FirebaseTSFirestore } from 'firebasets/firebasetsFirestore/firebaseTSFirestore';
import { FirebaseTSStorage } from 'firebasets/firebasetsStorage/firebaseTSStorage';
import { CreatePostComponent } from '../create-post/create-post.component';

@Component({
  selector: 'app-create-room',
  templateUrl: './create-room.component.html',
  styleUrls: ['./create-room.component.css']
})
export class CreateRoomComponent implements OnInit {
  auth = new FirebaseTSAuth();
  firestore=new FirebaseTSFirestore();
  storage=new FirebaseTSStorage();
  constructor(private dialog:MatDialogRef<CreatePostComponent>) { }

  ngOnInit(): void {
  }
  onRoomClick(commentInput:HTMLTextAreaElement){
    let comment=commentInput.value;
    let roomid=this.firestore.genDocId();
    this.firestore.create(
      {
        path:["Rooms"],
        data:{
          comment:comment,
          creatorId:this.auth.getAuth().currentUser?.uid,
          timestamp:FirebaseTSApp.getFirestoreTimestamp()
        },
        onComplete:(docId)=>{
          this.dialog.close();
        }

      }
     );
  }
}
