import { TestBed } from '@angular/core/testing';

import { GuardlogactivateGuard } from './guardlogactivate.guard';

describe('GuardlogactivateGuard', () => {
  let guard: GuardlogactivateGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(GuardlogactivateGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
