import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import{FirebaseTSApp} from 'firebasets/firebasetsApp/firebaseTSApp';
import { environment } from 'src/environments/environment';
import { HomeComponent } from './pages/home/home.component';
import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
import {MatCardModule} from '@angular/material/card';
import { AuthenticatorComponent } from './tools/authenticator/authenticator.component';

import {MatButtonModule} from '@angular/material/button';
import { EmailVerificationComponent } from './pages/email-verification/email-verification.component';
import { FormsModule } from '@angular/forms';

import { AngularFireAuthModule } from '@angular/fire/compat/auth';
import { ProfileComponent } from './tools/profile/profile.component';
import {MatDialogModule} from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { CreatePostComponent } from './tools/create-post/create-post.component';
import { PostComponent } from './tools/post/post.component';
import { PostFeedComponent } from './pages/post-feed/post-feed.component';
import { ReplyComponent } from './tools/reply/reply.component';
import { RoomlistComponent } from './pages/roomlist/roomlist.component';
import { CreateRoomComponent } from './tools/create-room/create-room.component';
import { RoomComponent } from './tools/room/room.component';
import { ChatComponent } from './tools/chat/chat.component';
import { ProfilefeedComponent } from './pages/profilefeed/profilefeed.component';
import {MatTabsModule} from '@angular/material/tabs';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AuthenticatorComponent,
    EmailVerificationComponent,
    ProfileComponent,
    CreatePostComponent,
    PostComponent,
    PostFeedComponent,
    ReplyComponent,
    RoomlistComponent,
    CreateRoomComponent,
    RoomComponent,
    ChatComponent,
    ProfilefeedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatBottomSheetModule,
    MatCardModule,
    MatButtonModule,
    FormsModule,
    AngularFireAuthModule,
    MatDialogModule,
    MatIconModule,
    MatTabsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor()
  {
    FirebaseTSApp.init(environment.firebaseConfig);
  }

 }
