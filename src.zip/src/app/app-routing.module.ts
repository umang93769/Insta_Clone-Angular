import { NgModule } from '@angular/core';
import { AppCheckModule } from '@angular/fire/app-check';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { GuardGuard } from './guard.guard';
import { GuardlogactivateGuard } from './guardlogactivate.guard';
import { EmailVerificationComponent } from './pages/email-verification/email-verification.component';
import { HomeComponent } from './pages/home/home.component';
import { PostFeedComponent } from './pages/post-feed/post-feed.component';
import { ProfilefeedComponent } from './pages/profilefeed/profilefeed.component';
import { RoomlistComponent } from './pages/roomlist/roomlist.component';

const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"emailVerification",component:EmailVerificationComponent},
  {path:"postfeed",component:PostFeedComponent,canActivate:[GuardlogactivateGuard]},
  {path:"home",component:HomeComponent},
  {path:"room",component:RoomlistComponent},
  {path:"account",component:ProfilefeedComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
