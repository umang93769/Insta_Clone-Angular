export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBtcpaWBrURsfm7rLnGJc_wZkl9NQitT2c",
    authDomain: "insta-clone-7412f.firebaseapp.com",
    projectId: "insta-clone-7412f",
    storageBucket: "insta-clone-7412f.appspot.com",
    messagingSenderId: "77073562660",
    appId: "1:77073562660:web:a4f2dedf83266f66c02cb1"
  }

};
